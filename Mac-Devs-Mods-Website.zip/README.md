# Mac Devs Mods

A static BONELAB mod library based on MapMenuPlus's UI. No category sidebar. Includes God Man 1.0.1 and Level Selector / MapMenuPlus 1.0.2, direct DLL downloads, DLL-only ZIPs, searchable cards, detail views, local favorites, installation instructions, and real GitHub Release download totals.

## Run locally

Requires Node 22 or newer and Python 3. No npm packages are required.

```sh
node scripts/build.mjs
python -m http.server 4173 --bind 127.0.0.1 --directory dist
```

Open http://127.0.0.1:4173. Local downloads work before publishing. Counts display a dash until the site has a repository with release assets; clicks never fabricate a count.

## Free GitHub Pages hosting

1. Create a new **public** GitHub repository named `mac-devs-mods`.
2. Upload this repository's contents, including `.github/workflows/publish.yml`, to the `main` branch. Do not upload the outer ZIP as a single file.
3. Open repository **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Open **Actions → Publish Mac Devs Mods → Run workflow** if the initial push ran before Pages was enabled.
5. The workflow publishes one GitHub Release per mod, uploads the DLL and DLL-only ZIP, then deploys the static site. It supplies the repository name automatically. The URL is `https://YOUR-USERNAME.github.io/mac-devs-mods/`.

The workflow uses GitHub's built-in token only on GitHub's runner. No tokens or passwords belong in site files. GitHub Pages is available for public repositories on GitHub Free: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Download totals

The browser reads each matching asset's `download_count` from the public GitHub Releases API and totals DLL + ZIP downloads across releases. These count file requests, not unique people. Totals are cached for ten minutes and refresh after a download or when revisiting the tab. If GitHub is unavailable or rate-limits the browser, the site displays cached totals or a dash. Download links remain available. Existing assets are not re-uploaded during routine deployments, so their counts are preserved.

API documentation: https://docs.github.com/en/rest/releases/releases

## Update pictures and mods

- Edit mod names, descriptions, versions and image paths in `site/config.js`.
- Level Selector uses the image supplied by the user at `site/assets/level-selector.jpg`.
- God Man uses the user-approved edited picture at `site/assets/god-man.png`.
- For a new mod release, replace its DLL and ZIP in `site/downloads/` and bump both `version` and `releaseTag` in `site/config.js`.
- Do not replace an existing GitHub release asset to update a mod: replacing it resets its download total.

## Credits

MapMenuPlus is originally by MafiaBossTeam. The Level Selector download includes the map discovery and map loading fixes made for this project. God Man is the custom BoneMenu mod made for this project. The UI colors and card/menu layout follow the supplied mod source and screenshot. Screenshots were supplied by the user. This website is an independent mod library.
