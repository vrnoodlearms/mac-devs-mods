window.MOD_SITE = {
  name: "Mac Devs Mods",
  repository: "",
  mods: [
    {
      id: "god-man",
      name: "God Man",
      version: "1.0.1",
      releaseTag: "god-man-v1.0.1",
      file: "GodMan.dll",
      zip: "GodMan-DLL-Only.zip",
      image: "assets/god-man.png",
      imageAlt: "God Man in gold lettering above a suited BONELAB avatar standing on a green bomb",
      icon: "shield",
      color: "gold",
      subtitle: "Immortality. One switch.",
      summary: "Enable Immortal in BoneMenu to block player damage and death calls while keeping your avatar’s normal maximum health.",
      features: ["BoneMenu → God Man → Immortal", "Damage and death protection", "Keeps your setting across maps and avatar swaps"],
      updated: "2026-11-02",
      changelog: "Startup fix: removes the shared collision hook and waits for the local player before installing protection.",
      author: "Mac Devs",
      note: "Built for BONELAB PC with MelonLoader and BoneLib. This build has not been tested in-game."
    },
    {
      id: "level-selector",
      name: "Level Selector",
      version: "1.0.2",
      releaseTag: "map-menu-plus-v1.0.2",
      file: "MapMenuPlus.dll",
      zip: "MapMenuPlus-DLL-Only.zip",
      image: "assets/level-selector.jpg",
      imageAlt: "The Level Selector in BONELAB, showing its map cards, search bar and mod map library",
      icon: "map",
      color: "blue",
      subtitle: "Your maps. All in one menu.",
      summary: "Browse installed mod maps and BONELAB’s sandbox maps in the same familiar menu, with map pictures, search, favorites and direct level loading.",
      features: ["Installed mod maps + built-in sandbox maps", "Map pictures, search and favorites", "Open from BONELAB’s Levels menu"],
      updated: "2026-11-02",
      changelog: "Fixes the “Could not start” error by using the game’s non-generic loading-screen check.",
      author: "MafiaBossTeam · fix by Mac Devs",
      note: "MapMenuPlus by MafiaBossTeam, with the local map-discovery and loading fixes. Requires MelonLoader and BoneLib."
    }
  ]
};
