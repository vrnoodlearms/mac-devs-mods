(() => {
  "use strict";
  const config = window.MOD_SITE;
  const mods = config.mods;
  const $ = (selector) => document.querySelector(selector);
  const escape = (value) => String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const icon = (name, extra = "") => `<svg class="icon ${extra}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const storage = {
    get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} }
  };
  const savedFavorites = storage.get("macdevs-favorites", []);
  const favorites = new Set(Array.isArray(savedFavorites) ? savedFavorites.filter(id => mods.some(m => m.id === id)) : []);
  const totals = new Map();
  const releaseLinks = new Map();
  let toastTimer;
  let previousRoute = null;
  let statsBusy = false;
  let lastStatsAttempt = 0;
  let repository = config.repository;
  if (!repository && location.hostname.endsWith(".github.io")) {
    const owner = location.hostname.slice(0, -10);
    const repo = location.pathname.split("/").filter(Boolean)[0] || `${owner}.github.io`;
    repository = `${owner}/${repo}`;
  }
  if (!/^[\w.-]+\/[\w.-]+$/.test(repository)) repository = "";
  const countKey = `macdevs-counts:${repository}`;
  const compact = new Intl.NumberFormat("en", {notation:"compact",maximumFractionDigits:1});
  const exact = new Intl.NumberFormat("en");
  const count = (id) => totals.has(id) ? compact.format(totals.get(id)) : "—";
  const size = (bytes) => bytes ? (bytes < 1048576 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / 1048576).toFixed(1)} MB`) : "DLL";

  function downloadUrl(mod, zip = false) {
    const filename = zip ? mod.zip : mod.file;
    if (releaseLinks.has(filename)) return releaseLinks.get(filename);
    return repository
      ? `https://github.com/${repository}/releases/download/${encodeURIComponent(mod.releaseTag)}/${encodeURIComponent(filename)}`
      : `downloads/${encodeURIComponent(filename)}`;
  }

  function imageContent(mod) {
    return mod.image
      ? `<img src="${escape(mod.image)}" alt="${escape(mod.imageAlt)}" width="1600" height="900" decoding="async">`
      : `<div class="placeholder-art">${icon(mod.icon)}<strong>${escape(mod.name.toUpperCase())}</strong><small>PICTURE COMING SOON</small></div>`;
  }

  function card(mod) {
    const favored = favorites.has(mod.id);
    return `<article class="mod-card" data-mod="${escape(mod.id)}">
      <a class="card-preview" href="#${escape(mod.id)}" aria-label="View ${escape(mod.name)} details">
        ${imageContent(mod)}<span class="preview-badge">BONELAB</span>
        <span class="card-stats">${icon("download")}<span data-count="${escape(mod.id)}">${count(mod.id)}</span><small>downloads</small></span>
      </a>
      <button class="favorite" data-favorite="${escape(mod.id)}" aria-label="${favored ? "Remove" : "Save"} ${escape(mod.name)} ${favored ? "from" : "to"} favorites" aria-pressed="${favored}">${icon("star")}</button>
      <div class="card-copy"><div class="card-title-line"><h2><a href="#${escape(mod.id)}">${escape(mod.name)}</a></h2><span class="version">v${escape(mod.version)}</span></div><p class="card-subtitle">${escape(mod.subtitle)}</p></div>
      <div class="card-actions"><a class="button download-button" href="${escape(downloadUrl(mod))}" download="${escape(mod.file)}" data-download="${escape(mod.id)}">${icon("download")} DOWNLOAD</a><a class="button details-button" href="#${escape(mod.id)}">DETAILS ${icon("arrow")}</a></div>
    </article>`;
  }

  function renderLibrary() {
    const query = $("#search").value.trim().toLocaleLowerCase();
    const matching = mods.filter(mod => `${mod.name} ${mod.subtitle} ${mod.summary}`.toLocaleLowerCase().includes(query));
    matching.sort((a, b) => {
      if ($("#sort").value === "downloads") return (totals.get(b.id) ?? -1) - (totals.get(a.id) ?? -1) || a.name.localeCompare(b.name);
      if ($("#sort").value === "recent") return b.updated.localeCompare(a.updated) || a.name.localeCompare(b.name);
      return a.name.localeCompare(b.name);
    });
    $("#mod-grid").innerHTML = matching.map(card).join("");
    $("#empty-state").hidden = matching.length !== 0;
    $("#result-count").textContent = query ? `${matching.length} OF ${mods.length} MODS` : `${mods.length} AVAILABLE`;
  }

  function detail(mod) {
    const index = mods.indexOf(mod);
    const favored = favorites.has(mod.id);
    return `<div class="detail-toolbar"><a class="button" href="#">${icon("arrow", "reverse")} BACK</a><span class="detail-crumb">MODS / ${escape(mod.name.toUpperCase())}</span><div class="detail-steps"><button class="button icon-button" data-step="-1" aria-label="Previous mod" ${index === 0 ? "disabled" : ""}>${icon("arrow", "reverse")}</button><span>${index + 1} / ${mods.length}</span><button class="button icon-button" data-step="1" aria-label="Next mod" ${index === mods.length - 1 ? "disabled" : ""}>${icon("arrow")}</button></div></div>
      <div class="detail-image">${imageContent(mod)}</div>
      <div class="detail-heading"><h2>${escape(mod.name)}</h2><span class="version">v${escape(mod.version)}</span></div>
      <p class="detail-author">${escape(mod.author)}</p>
      <div class="detail-stats"><span>${icon("download")}<strong data-count="${escape(mod.id)}">${count(mod.id)}</strong> downloads</span><span>${icon("box")}${escape(mod.file)} · ${size(mod.fileBytes)}</span><span>Updated ${new Date(mod.updated + "T12:00:00").toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</span></div>
      <p class="detail-description">${escape(mod.summary)}</p>
      <div class="feature-list">${mod.features.map(feature => `<span>${escape(feature)}</span>`).join("")}</div>
      <div class="detail-actions"><a class="button download-button" href="${escape(downloadUrl(mod))}" download="${escape(mod.file)}" data-download="${escape(mod.id)}">${icon("download")} DOWNLOAD DLL</a><button class="button favorite-detail" data-favorite="${escape(mod.id)}" aria-pressed="${favored}">${icon("star")} ${favored ? "FAVORITED" : "FAVORITE"}</button><a class="button zip-download" href="${escape(downloadUrl(mod,true))}" download="${escape(mod.zip)}" data-download="${escape(mod.id)}">DLL-ONLY ZIP ${icon("download")}</a><button class="text-button" data-install>How to install ↗</button></div>
      <details class="release-notes"><summary>WHAT’S NEW IN v${escape(mod.version)}</summary><p>${escape(mod.changelog)}</p><p>${escape(mod.note)}</p></details>`;
  }

  function route() {
    let id;
    try { id = decodeURIComponent(location.hash.slice(1)); } catch { id = ""; }
    const mod = mods.find(item => item.id === id);
    $("#library-view").hidden = Boolean(mod);
    $("#detail-view").hidden = !mod;
    document.title = mod ? `${mod.name} — Mac Devs Mods` : "Mac Devs Mods — BONELAB Mods";
    if (mod) {
      $("#detail-view").innerHTML = detail(mod);
      if (previousRoute !== id) $("#detail-view").focus({preventScroll:true});
    } else {
      renderLibrary();
      if (previousRoute) $("#search").focus({preventScroll:true});
    }
    previousRoute = mod?.id ?? "";
  }

  function toast(message) {
    clearTimeout(toastTimer);
    $("#toast").textContent = message;
    $("#toast").hidden = false;
    toastTimer = setTimeout(() => { $("#toast").hidden = true; }, 4200);
  }

  function updateCounts() {
    document.querySelectorAll("[data-count]").forEach(element => {
      const id = element.dataset.count;
      element.textContent = count(id);
      element.title = totals.has(id) ? `${exact.format(totals.get(id))} downloads on GitHub Releases` : "Download count currently unavailable";
    });
    if ($("#sort").value === "downloads" && !$("#library-view").hidden) renderLibrary();
  }

  async function refreshStats(force = false) {
    if (!repository) {
      $("#count-status").textContent = "Download totals available when published";
      return;
    }
    const cached = storage.get(countKey, null);
    if (cached && cached.counts && Number.isFinite(cached.time)) {
      for (const mod of mods) if (Number.isSafeInteger(cached.counts[mod.id]) && cached.counts[mod.id] >= 0) totals.set(mod.id, cached.counts[mod.id]);
      updateCounts();
      $("#count-status").textContent = `Counts updated ${new Date(cached.time).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}`;
      if (!force && Date.now() - cached.time < 600000) return;
    }
    if (statsBusy || Date.now() - lastStatsAttempt < 30000) return;
    lastStatsAttempt = Date.now();
    statsBusy = true;
    try {
      const releases = [];
      let page = 1;
      while (true) {
        const response = await fetch(`https://api.github.com/repos/${repository}/releases?per_page=100&page=${page}`, {headers:{Accept:"application/vnd.github+json"},signal:AbortSignal.timeout(12000)});
        if (!response.ok) throw new Error(`GitHub returned ${response.status}`);
        const batch = await response.json();
        if (!Array.isArray(batch)) throw new Error("Invalid release response");
        releases.push(...batch.filter(release => !release.draft && !release.prerelease));
        if (batch.length < 100) break;
        if (++page > 20) throw new Error("Release history too large to total accurately");
      }
      for (const mod of mods) {
        let total = 0;
        let found = false;
        for (const release of releases) {
          for (const asset of release.assets ?? []) {
            if (![mod.file, mod.zip].includes(asset.name)) continue;
            if (!Number.isSafeInteger(asset.download_count) || asset.download_count < 0) continue;
            found = true;
            total += asset.download_count;
            if (release.tag_name === mod.releaseTag && typeof asset.browser_download_url === "string" && asset.browser_download_url.startsWith(`https://github.com/${repository}/releases/download/`)) releaseLinks.set(asset.name, asset.browser_download_url);
          }
        }
        if (found) totals.set(mod.id, total);
        else totals.delete(mod.id);
      }
      const time = Date.now();
      storage.set(countKey,{time,counts:Object.fromEntries(totals)});
      updateCounts();
      $("#count-status").textContent = totals.size === mods.length ? "Live download totals · GitHub Releases" : "Download totals pending release";
    } catch {
      $("#count-status").textContent = totals.size ? "Showing saved download totals" : "Download totals temporarily unavailable";
    } finally { statsBusy = false; }
  }

  document.addEventListener("click", event => {
    const favorite = event.target.closest("[data-favorite]");
    if (favorite) {
      const id = favorite.dataset.favorite;
      favorites.has(id) ? favorites.delete(id) : favorites.add(id);
      storage.set("macdevs-favorites",[...favorites]);
      favorite.setAttribute("aria-pressed",String(favorites.has(id)));
      const mod = mods.find(item => item.id === id);
      favorite.setAttribute("aria-label",`${favorites.has(id) ? "Remove" : "Save"} ${mod.name} ${favorites.has(id) ? "from" : "to"} favorites`);
      if (favorite.classList.contains("favorite-detail")) favorite.innerHTML = `${icon("star")} ${favorites.has(id) ? "FAVORITED" : "FAVORITE"}`;
    }
    const download = event.target.closest("[data-download]");
    if (download) {
      const mod = mods.find(item => item.id === download.dataset.download);
      toast(`${mod.name}: put the extracted DLL in BONELAB’s Mods folder.`);
      // GitHub counts actual asset requests. Never fabricate a local increment.
      setTimeout(() => refreshStats(true), 35000);
    }
    const step = event.target.closest("[data-step]");
    if (step) {
      const index = mods.findIndex(item => `#${item.id}` === location.hash);
      const next = mods[index + Number(step.dataset.step)];
      if (next) location.hash = next.id;
    }
    if (event.target.closest("[data-install]")) $("#install-dialog").showModal();
  });

  $("#search").addEventListener("input",renderLibrary);
  $("#sort").addEventListener("change",renderLibrary);
  $("#clear-search").addEventListener("click",() => { $("#search").value = ""; renderLibrary(); $("#search").focus(); });
  ["#install-open","#install-inline"].forEach(selector => $(selector).addEventListener("click",() => $("#install-dialog").showModal()));
  $("#install-close").addEventListener("click",() => $("#install-dialog").close());
  $("#install-dialog").addEventListener("click", event => { if (event.target === event.currentTarget) { const box = event.currentTarget.getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) event.currentTarget.close(); } });
  $("#copy-path").addEventListener("click", async () => {
    const text = $(".install-path code").textContent;
    try { await navigator.clipboard.writeText(text); toast("BONELAB Mods folder path copied."); }
    catch { const range = document.createRange(); range.selectNodeContents($(".install-path code")); const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range); toast("Folder path selected. Press Ctrl+C to copy."); }
  });
  $("#close-menu").addEventListener("click",() => {
    if (mods.some(item => `#${item.id}` === location.hash)) { location.hash = ""; return; }
    $("#menu-panel").hidden = true; $("#closed-menu").hidden = false; $("#open-menu").focus();
  });
  $("#open-menu").addEventListener("click",() => { $("#menu-panel").hidden = false; $("#closed-menu").hidden = true; $("#search").focus(); });
  window.addEventListener("hashchange",route);
  document.addEventListener("visibilitychange",() => { if (!document.hidden) refreshStats(); });
  $("#mod-total").textContent = mods.length;
  $("#status-text").textContent = `${mods.length} mods available`;
  route();
  refreshStats();
})();
