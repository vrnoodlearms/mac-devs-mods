import { readFile, writeFile, mkdir, cp, stat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import vm from 'node:vm';

const root = resolve(import.meta.dirname, '..');
const context = { window: {} };
vm.runInNewContext(await readFile(join(root, 'site/config.js'), 'utf8'), context);
const config = JSON.parse(JSON.stringify(context.window.MOD_SITE));
const repository = process.env.GITHUB_REPOSITORY || config.repository;
if (repository && !/^[\w.-]+\/[\w.-]+$/.test(repository)) throw new Error('Invalid repository name');
config.repository = repository;
for (const mod of config.mods) {
  mod.fileBytes = (await stat(join(root, 'site/downloads', mod.file))).size;
  await stat(join(root, 'site/downloads', mod.zip));
  if (mod.image) await stat(join(root, 'site', mod.image));
}
await mkdir(join(root, 'dist'), {recursive:true});
await cp(join(root, 'site'), join(root, 'dist'), {recursive:true});
await writeFile(join(root, 'dist/config.js'), `window.MOD_SITE = ${JSON.stringify(config,null,2)};\n`);
await writeFile(join(root, 'dist/.nojekyll'), '');
console.log(`Built Mac Devs Mods: ${config.mods.length} mods. ${repository || 'Local preview'}`);
