import { readFile, stat } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import vm from 'node:vm';

const root = resolve(import.meta.dirname, '..');
const repository = process.env.GITHUB_REPOSITORY;
if (!repository || !/^[\w.-]+\/[\w.-]+$/.test(repository)) throw new Error('GITHUB_REPOSITORY is required');
const context = { window:{} };
vm.runInNewContext(await readFile(join(root,'site/config.js'),'utf8'),context);
const gh = args => execFileSync('gh',args,{encoding:'utf8',stdio:['ignore','pipe','pipe']});
// Listing first distinguishes a missing release from permission/network errors.
const pages = JSON.parse(gh(['api',`repos/${repository}/releases?per_page=100`,'--paginate','--slurp']));
const releases = pages.flat();
for (const mod of context.window.MOD_SITE.mods) {
  const files = [mod.file,mod.zip];
  let release = releases.find(item => item.tag_name === mod.releaseTag);
  if (!release) {
    gh(['release','create',mod.releaseTag,'--repo',repository,'--target',process.env.GITHUB_SHA || 'main',
      '--title',`${mod.name} v${mod.version}`,'--notes',`${mod.summary}\n\n${mod.changelog}\n\n${mod.note}\n\nInstall only the DLL into the BONELAB game Mods folder. ZIP downloads contain only the DLL.`,
      ...files.map(file => join(root,'site/downloads',file))]);
    console.log(`Published ${mod.releaseTag}`);
    continue;
  }
  if (release.draft || release.prerelease) throw new Error(`${mod.releaseTag} must be a published stable release`);
  for (const file of files) {
    const path = join(root,'site/downloads',file);
    const asset = release.assets.find(item => item.name === file);
    if (!asset) {
      gh(['release','upload',mod.releaseTag,path,'--repo',repository]);
      continue;
    }
    const digest = 'sha256:' + createHash('sha256').update(await readFile(path)).digest('hex');
    if ((asset.digest && digest !== asset.digest) || asset.size !== (await stat(path)).size)
      throw new Error(`${file} changed: bump its version and releaseTag instead of replacing an asset and losing its download count.`);
  }
  console.log(`Kept ${mod.releaseTag} and its existing download counts`);
}
